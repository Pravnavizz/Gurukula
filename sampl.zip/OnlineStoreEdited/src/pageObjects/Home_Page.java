package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.Log;
import utility.Utils;

public class Home_Page extends BaseClass {
	private static WebElement element = null;

	public Home_Page() throws InterruptedException {
		super(driver);
	}

	public static WebElement loginLink() throws Exception {
		try {
			element = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div[1]/a"));
			Log.info("Login link is found");
		} catch (Exception e) {
			Log.error("Login link is not found on the Home Page");
			throw (e);
		}
		return element;
	}

	public static WebElement Account() throws Exception {
		try {
			element = driver.findElement(By.xpath("//span[contains(text(),'Account')]"));

			Log.info("Account Options link is found on the Home Page");
		} catch (Exception e) {
			Log.error("Log Out link is not found on the Home Page");
			throw (e);
		}
		return element;
	}
	
	public static WebElement lnk_LogOut() throws Exception {
		try {
			element = driver.findElement(By.id("account_logout"));

			Log.info("Log Out link is found on the Home Page");
		} catch (Exception e) {
			Log.error("Log Out link is not found on the Home Page");
			throw (e);
		}
		return element;
	}

}
